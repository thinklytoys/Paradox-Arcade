package com.paradox.arcade

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PanelDark = Color(0xFF171025)

// ============================================================ L1: Achilles

@Composable
fun Level1Achilles(onComplete: (String) -> Unit) {
    var gap by remember { mutableFloatStateOf(100f) }
    var taps by remember { mutableIntStateOf(0) }

    LevelScaffold("The Endless Chase", "Achilles and the Tortoise", onExit = { onComplete("Left mid-chase") }) {
        Text(
            "The tortoise has a head start. Every time you stride forward, you close HALF the " +
                "remaining gap between you. Nothing more, nothing less. Try to catch it.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))
        Text("Gap remaining: ${"%.3f".format(gap)} m", color = NeonCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Strides taken: $taps", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))

        ArcadeButton("Take a stride (halve the gap)", {
            gap /= 2f
            taps += 1
        }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(14.dp))
        if (taps >= 6) {
            InfoCard("By this rule, you can stride forever and the gap never quite reaches zero. That's Zeno's argument - motion looks impossible on paper.")
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Break the rule - just run past it", {
                onComplete("Broke the halving rule after $taps strides and simply ran past.")
            }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
            Spacer(Modifier.height(10.dp))
            InfoCard(
                "In reality Achilles obviously passes the tortoise - you just did it too. The paradox isn't " +
                    "about the real world, it's about the description: infinitely many halved steps still add " +
                    "up to a small, finite distance and a finite time. Calculus proved this centuries later - " +
                    "an infinite sum can converge to a finite number.",
                tint = PanelDark
            )
        }
    }
}

// =========================================================== L2: Ship

@Composable
fun Level2Ship(onComplete: (String) -> Unit) {
    val planks = remember { mutableStateListOf(*Array(8) { false }) }
    var answered by remember { mutableStateOf<String?>(null) }
    val replacedCount = planks.count { it }

    LevelScaffold("The Old Ship", "Ship of Theseus", onExit = { onComplete("Left with $replacedCount/8 planks replaced") }) {
        Text(
            "An old ship needs repair. Tap each plank to replace it with new timber, one at a time. " +
                "Once replaced, a plank can't go back to being original.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in planks.indices) {
                Box(
                    modifier = Modifier
                        .size(width = 32.dp, height = 48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (planks[i]) NeonCyan else Color(0xFF7A5A2E))
                        .clickable(enabled = !planks[i]) { planks[i] = true }
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Replaced: $replacedCount / 8", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))

        if (replacedCount == 8 && answered == null) {
            InfoCard("Every original plank is gone. Not one atom of the ship you started with remains.")
            Spacer(Modifier.height(14.dp))
            Text("Is this still the same ship?", color = InkText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("Yes, same ship", { answered = "Same ship" }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("No, different ship", { answered = "Different ship" }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
        } else if (answered != null) {
            InfoCard(
                "There's no settled answer - philosophers have argued this one for over two thousand years. " +
                    "Some say identity lives in the material, some say it lives in the continuous form and " +
                    "function. Your answer: \"$answered\". No test in this game will ever mark that wrong.",
                tint = PanelDark
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Said: $answered") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

// =========================================================== L3: Chest

@Composable
fun Level3Chest(state: GameState, onComplete: (String) -> Unit) {
    val digits = remember { mutableStateListOf(0, 0, 0, 0) }
    var message by remember { mutableStateOf<String?>(null) }

    LevelScaffold("The Locked Chest", "Bootstrap Paradox", onExit = { onComplete(if (state.chestOpened) "Opened, no origin" else "Visited, still locked") }) {
        Text(
            "A chest, sealed with a four-digit code. Tap each digit to cycle it 0-9. " +
                "Nobody remembers who set this code, or when.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in digits.indices) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PanelColor)
                        .clickable { digits[i] = (digits[i] + 1) % 10 },
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text("${digits[i]}", color = NeonPink, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        ArcadeButton("Try this code", {
            val entered = digits.joinToString("")
            val target = state.vaultCode
            message = when {
                target == null -> "This code doesn't exist anywhere yet. Maybe it will, later. Maybe elsewhere."
                entered == target -> "MATCH"
                else -> "Not quite. Nothing happens."
            }
            if (message == "MATCH") {
                state.chestOpened = true
            }
        }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(14.dp))
        val m = message
        if (m == "MATCH") {
            InfoCard(
                "The chest opens. Inside, a note in your own handwriting reads the code you just entered - " +
                    "the same code you're about to receive, later, from somewhere else. " +
                    "This code has no first moment of being created. That's the Bootstrap Paradox: " +
                    "information trapped in a loop, with no origin at all.",
                tint = PanelDark
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Opened using a code with no origin.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
        } else if (m != null) {
            InfoCard(m)
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Leave the chest for now", { onComplete("Visited, still locked") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

// =========================================================== L4: Heap

@Composable
fun Level4Heap(onComplete: (String) -> Unit) {
    var grains by remember { mutableFloatStateOf(1000f) }
    var isHeap by remember { mutableStateOf(true) }
    val readings = remember { mutableStateListOf<Pair<Int, Boolean>>() }

    LevelScaffold("The Heap", "Sorites Paradox", onExit = { onComplete("Left with ${readings.size} readings logged") }) {
        Text(
            "Drag the slider to remove grains of sand from the heap. At any point, flip the switch to say " +
                "whether it's still a heap, and log your reading.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))
        Text("Grains: ${grains.toInt()}", color = NeonCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Slider(value = grains, onValueChange = { grains = it }, valueRange = 0f..1000f)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(if (isHeap) "Still a heap" else "Not a heap", color = InkText, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Switch(checked = isHeap, onCheckedChange = { isHeap = it })
        }
        Spacer(Modifier.height(14.dp))
        ArcadeButton("Log this reading", {
            readings.add(grains.toInt() to isHeap)
        }, modifier = Modifier.fillMaxWidth())

        if (readings.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("YOUR READINGS", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            for ((count, heap) in readings) {
                InfoCard("$count grains → ${if (heap) "heap" else "not a heap"}", tint = PanelDark)
                Spacer(Modifier.height(6.dp))
            }
        }

        if (readings.size >= 4) {
            Spacer(Modifier.height(10.dp))
            InfoCard(
                "Somewhere between your readings, you flipped from \"heap\" to \"not a heap.\" But there is no " +
                    "single grain whose removal should make that difference - remove one grain from any heap " +
                    "and it's still obviously a heap. Repeat that reasoning grain by grain and you're forced " +
                    "to conclude one grain is a heap too. Vagueness has no sharp edge. That's the Sorites Paradox.",
                tint = PanelDark
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Logged ${readings.size} readings; flip point stayed fuzzy.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
        }
    }
}
