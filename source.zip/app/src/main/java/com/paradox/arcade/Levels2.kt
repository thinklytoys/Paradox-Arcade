package com.paradox.arcade

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val PanelDark2 = Color(0xFF171025)

// ============================================================ L5: Liar

private data class Statement(val text: String, val special: Boolean = false)

private val statements = listOf(
    Statement("2 + 2 = 4"),
    Statement("Bangalore is in India"),
    Statement("The sky is, on a clear day, green"),
    Statement("A triangle has three sides"),
    Statement("This statement is false.", special = true)
)

@Composable
fun Level5Liar(onComplete: (String) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var jammed by remember { mutableStateOf<String?>(null) }

    LevelScaffold("The Truth Machine", "Liar Paradox", onExit = { onComplete("Left at statement ${index + 1}/${statements.size}") }) {
        Text("A machine that sorts statements into TRUE or FALSE. Feed it one at a time.", color = InkText, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))

        if (index < statements.size) {
            val current = statements[index]
            InfoCard("\"${current.text}\"", tint = PanelDark2)
            Spacer(Modifier.height(16.dp))

            if (jammed == null) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ArcadeButton("TRUE", {
                        if (current.special) {
                            jammed = "If the machine marks this TRUE, then the statement is telling the truth about " +
                                "being false - so it must actually be FALSE. Contradiction."
                        } else {
                            index += 1
                        }
                    }, modifier = Modifier.weight(1f), tint = NeonCyan)
                    ArcadeButton("FALSE", {
                        if (current.special) {
                            jammed = "If the machine marks this FALSE, then it's false that it's false - so it must " +
                                "actually be TRUE. Contradiction."
                        } else {
                            index += 1
                        }
                    }, modifier = Modifier.weight(1f), tint = NeonPink)
                }
            }

            if (jammed != null) {
                Spacer(Modifier.height(14.dp))
                InfoCard(jammed ?: "", tint = Color(0xFF3A0F26))
                Spacer(Modifier.height(12.dp))
                InfoCard(
                    "Every classification loops back into its own opposite. There is no consistent TRUE or " +
                        "FALSE for this sentence - it isn't a hard case, it's a genuine hole in the classification " +
                        "system itself. That's the Liar Paradox.",
                    tint = PanelDark2
                )
                Spacer(Modifier.height(12.dp))
                ArcadeButton("Mark UNCLASSIFIABLE and move on", {
                    onComplete("The machine jammed on statement 5 - correctly, since it can't be classified.")
                }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
            }
        }
    }
}

// ======================================================= L6: Monty Hall

@Composable
fun Level6MontyHall(onComplete: (String) -> Unit) {
    var prizeDoor by remember { mutableIntStateOf(Random.nextInt(3)) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var revealed by remember { mutableStateOf<Int?>(null) }
    var finalChoice by remember { mutableStateOf<Int?>(null) }
    var switchWins by remember { mutableIntStateOf(0) }
    var switchLosses by remember { mutableIntStateOf(0) }
    var stayWins by remember { mutableIntStateOf(0) }
    var stayLosses by remember { mutableIntStateOf(0) }
    val totalRounds = switchWins + switchLosses + stayWins + stayLosses

    fun newRound() {
        prizeDoor = Random.nextInt(3)
        picked = null
        revealed = null
        finalChoice = null
    }

    LevelScaffold("Three Doors", "Monty Hall Problem", onExit = { onComplete("Played $totalRounds rounds") }) {
        Text(
            "Pick a door. The host, who knows where the prize is, opens a different door with nothing " +
                "behind it. Then you decide: stick with your door, or switch to the last one.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (d in 0..2) {
                val isPicked = picked == d
                val isRevealed = revealed == d
                val label = when {
                    finalChoice != null && d == prizeDoor -> "★"
                    isRevealed -> "🐐"
                    else -> "?"
                }
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isPicked) NeonPink else PanelDark2)
                        .clickable(enabled = picked == null) {
                            picked = d
                            val candidates = (0..2).filter { it != d && it != prizeDoor }
                            revealed = candidates.random()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 26.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (picked != null && revealed != null && finalChoice == null) {
            val other = (0..2).first { it != picked && it != revealed }
            InfoCard("Door ${revealed!! + 1} had nothing. Stay with door ${picked!! + 1}, or switch to door ${other + 1}?")
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("Stay", {
                    finalChoice = picked
                    if (picked == prizeDoor) stayWins += 1 else stayLosses += 1
                }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("Switch", {
                    finalChoice = other
                    if (other == prizeDoor) switchWins += 1 else switchLosses += 1
                }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
        }

        if (finalChoice != null) {
            Spacer(Modifier.height(14.dp))
            val won = finalChoice == prizeDoor
            InfoCard(if (won) "You found the prize!" else "Nothing there this time.", tint = if (won) Color(0xFF0F3A26) else Color(0xFF3A0F26))
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Play another round", { newRound() }, modifier = Modifier.fillMaxWidth())
        }

        if (totalRounds > 0) {
            Spacer(Modifier.height(20.dp))
            Text("RUNNING TALLY", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            val switchTotal = switchWins + switchLosses
            val stayTotal = stayWins + stayLosses
            val switchPct = if (switchTotal > 0) (switchWins * 100 / switchTotal) else 0
            val stayPct = if (stayTotal > 0) (stayWins * 100 / stayTotal) else 0
            InfoCard("Switched $switchTotal times → won $switchPct% of them", tint = PanelDark2)
            Spacer(Modifier.height(6.dp))
            InfoCard("Stayed $stayTotal times → won $stayPct% of them", tint = PanelDark2)
        }

        if (totalRounds >= 6) {
            Spacer(Modifier.height(14.dp))
            InfoCard(
                "Switching should win roughly twice as often as staying, over enough rounds. Your first door " +
                    "had a 1-in-3 chance; the host's reveal doesn't touch that - it just concentrates the other " +
                    "2-in-3 chance onto the one door left standing.",
                tint = PanelDark2
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton(
                "Continue",
                { onComplete("Played $totalRounds rounds - switching won more often, as it should.") },
                modifier = Modifier.fillMaxWidth(),
                tint = GoodGreen
            )
        }
    }
}

// ========================================================= L7: Hotel

@Composable
fun Level7Hotel(onComplete: (String) -> Unit) {
    val log = remember { mutableStateListOf("The Grand Hotel has infinitely many rooms. Every single one is occupied. \"No Vacancy\" has been lit for a thousand years.") }
    var stage by remember { mutableIntStateOf(0) }

    LevelScaffold("No Vacancy", "Hilbert's Grand Hotel", onExit = { onComplete("Left at stage $stage") }) {
        Row {
            for (i in 1..8) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonPink)
                        .padding(2.dp)
                )
                Spacer(Modifier.width(4.dp))
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Rooms 1, 2, 3, 4, 5, 6, 7, 8 ... forever", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        for (line in log) {
            InfoCard(line, tint = PanelDark2)
            Spacer(Modifier.height(6.dp))
        }

        Spacer(Modifier.height(10.dp))
        when (stage) {
            0 -> ArcadeButton("One new guest arrives", {
                log.add("Every current guest moves from room n to room n+1. Room 1 is now free.")
                log.add("The new guest checks into room 1. The hotel is, once again, completely full.")
                stage = 1
            }, modifier = Modifier.fillMaxWidth())

            1 -> ArcadeButton("An infinite bus of new guests arrives", {
                log.add("Every current guest moves from room n to room 2n - into the even-numbered rooms.")
                log.add("Every odd-numbered room - infinitely many of them - is now free.")
                log.add("The infinite busload checks in, one guest per odd room. The hotel is, somehow, still completely full.")
                stage = 2
            }, modifier = Modifier.fillMaxWidth())

            2 -> {
                InfoCard(
                    "A \"full\" infinite hotel can always make room for more - because infinity plus one is " +
                        "still the same infinity, and infinity times two is too. Georg Cantor proved some " +
                        "infinities are still bigger than others - but this particular kind can always shuffle " +
                        "to make space. That's Hilbert's Hotel.",
                    tint = PanelDark2
                )
                Spacer(Modifier.height(12.dp))
                ArcadeButton("Continue", { onComplete("Fit one guest, then an infinite bus, into an already-full hotel.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
            }
        }
    }
}

// ======================================================= L8: Newcomb

@Composable
fun Level8Newcomb(onComplete: (String) -> Unit) {
    var choice by remember { mutableStateOf<String?>(null) }
    var simmed by remember { mutableStateOf(false) }

    LevelScaffold("Two Boxes", "Newcomb's Paradox", onExit = { onComplete("Left without choosing") }) {
        Text(
            "Box A is clear: it always holds \$1,000. Box B is sealed. An extremely accurate predictor " +
                "filled Box B BEFORE you arrived - with \$1,000,000 if it predicted you'd take only Box B, " +
                "or nothing if it predicted you'd take both.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))

        if (choice == null) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("Take only Box B", { choice = "one-box" }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("Take both boxes", { choice = "two-box" }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
        } else {
            InfoCard(
                if (choice == "one-box")
                    "You took only Box B. The dominance argument says this is silly - taking Box A too can " +
                        "never make you worse off, since the boxes are already filled. And yet."
                else
                    "You took both boxes. The dominance argument backs you completely - whatever's in Box B, " +
                        "Box A's \$1,000 is pure bonus on top of it.",
                tint = PanelDark2
            )
            Spacer(Modifier.height(14.dp))
            if (!simmed) {
                ArcadeButton("Simulate 200 predictor rounds (90% accurate)", {
                    simmed = true
                }, modifier = Modifier.fillMaxWidth())
            } else {
                val rng = Random(42)
                var oneBoxTotal = 0L
                var twoBoxTotal = 0L
                repeat(200) {
                    val predictedOneBox = rng.nextDouble() < 0.90
                    oneBoxTotal += if (predictedOneBox) 1_000_000L else 0L
                    val predictedTwoBox = rng.nextDouble() < 0.90
                    twoBoxTotal += 1_000L + if (!predictedTwoBox) 1_000_000L else 0L
                }
                val oneBoxAvg = oneBoxTotal / 200
                val twoBoxAvg = twoBoxTotal / 200
                InfoCard("Across 200 simulated rounds: one-boxers averaged \$$oneBoxAvg. Two-boxers averaged \$$twoBoxAvg.", tint = Color(0xFF171025))
                Spacer(Modifier.height(12.dp))
                InfoCard(
                    "Two-boxing wins the logic of dominance. One-boxing wins the actual money, on average, " +
                        "against a good predictor. Both arguments are individually airtight, and they disagree. " +
                        "That's Newcomb's Paradox - decision theory doesn't fully agree with itself here.",
                    tint = PanelDark2
                )
                Spacer(Modifier.height(12.dp))
                ArcadeButton("Continue", { onComplete("Chose $choice; saw one-box average beat two-box average.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
            }
        }
    }
}
