package com.paradox.arcade

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PanelDark3 = Color(0xFF171025)

// ========================================================= L9: Signal

@Composable
fun Level9Signal(state: GameState, onComplete: (String) -> Unit) {
    var revealedDigits by remember { mutableIntStateOf(0) }

    LevelScaffold("The Signal", "Bootstrap Paradox", onExit = { onComplete("Left mid-decode ($revealedDigits/4 digits)") }) {
        Text(
            "Static, then a faint pattern. You find yourself humming along to a tune you've never heard, " +
                "tapping out a number you were never taught. Listen closely, one digit at a time.",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))

        val revealed = if (state.vaultCode != null) state.vaultCode!!.take(revealedDigits) else ""
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until 4) {
                val shown = if (i < revealedDigits && state.vaultCode != null) state.vaultCode!![i].toString() else "?"
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PanelDark3),
                    contentAlignment = Alignment.Center
                ) {
                    Text(shown, color = NeonCyan, fontSize = 24.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(18.dp))

        if (revealedDigits < 4) {
            ArcadeButton("Listen closer", {
                if (state.vaultCode == null) state.revealVaultCode()
                revealedDigits += 1
            }, modifier = Modifier.fillMaxWidth())
        } else {
            InfoCard(
                "The number is complete: ${state.vaultCode}. You didn't calculate it, remember it, or invent it - " +
                    "it was simply always there to be received. Nobody first wrote it down; you're just the " +
                    "latest person to pass it along, the same way it was passed to you.",
                tint = PanelDark3
            )
            Spacer(Modifier.height(14.dp))
            InfoCard(
                "That's the Bootstrap Paradox: information (or a tune, or an invention) that loops through " +
                    "time with no true origin. If you remember The Locked Chest, you might want to visit it again.",
                tint = Color(0xFF0F3A26)
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Decoded ${state.vaultCode} - a number with no origin.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
        }
    }
}

// ===================================================== L10: Boy or Girl

@Composable
fun Level10BoyGirl(onComplete: (String) -> Unit) {
    var guess by remember { mutableStateOf<String?>(null) }

    LevelScaffold("Two Children", "Boy or Girl Paradox", onExit = { onComplete("Left without answering") }) {
        Text(
            "A family has exactly two children. You're told: at least one of them is a boy. " +
                "What's the probability the OTHER child is also a boy?",
            color = InkText, fontSize = 15.sp
        )
        Spacer(Modifier.height(18.dp))

        if (guess == null) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("1/2", { guess = "1/2" }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("1/3", { guess = "1/3" }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
        } else {
            Text("Every equally-likely family of two children, oldest first:", color = InkText, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            val combos = listOf("Boy, Boy" to true, "Boy, Girl" to true, "Girl, Boy" to true, "Girl, Girl" to false)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((label, keep) in combos) {
                    Box(
                        modifier = Modifier
                            .size(width = 76.dp, height = 56.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (keep) PanelDark3 else Color(0xFF3A0F26)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = if (keep) InkText else Color(0xFF7A5270), fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            InfoCard(
                "\"Girl, Girl\" is ruled out - we were told at least one is a boy. That leaves 3 equally likely " +
                    "families, and only 1 of those 3 has a second boy. The answer is 1/3, not 1/2 - " +
                    "\"at least one boy\" rules out more girl-heavy families than you'd expect.",
                tint = PanelDark3
            )
            Spacer(Modifier.height(12.dp))
            InfoCard(
                "Push it further: \"at least one boy born on a Tuesday\" changes the answer again, to 13/27 - " +
                    "a seemingly irrelevant detail (which day!) shifts the odds. Most people's intuition never " +
                    "recovers from that one.",
                tint = Color(0xFF171025)
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Guessed $guess; correct answer is 1/3.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
        }
    }
}

// ======================================================== L11: Ravens

private data class RavenCard(val label: String, val isRaven: Boolean, val isBlack: Boolean)

private val ravenCards = listOf(
    RavenCard("A raven, black as night", isRaven = true, isBlack = true),
    RavenCard("A red apple", isRaven = false, isBlack = false),
    RavenCard("A brown shoe", isRaven = false, isBlack = false),
    RavenCard("Another black raven", isRaven = true, isBlack = true),
    RavenCard("A green parrot feather", isRaven = false, isBlack = false)
)

@Composable
fun Level11Ravens(onComplete: (String) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var lastNote by remember { mutableStateOf<String?>(null) }

    LevelScaffold("All Ravens", "Raven Paradox", onExit = { onComplete("Left at card ${index + 1}/${ravenCards.size}") }) {
        Text("The claim on trial: \"All ravens are black.\" Look at each thing you find and decide: does it relate?", color = InkText, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))

        if (index < ravenCards.size) {
            val card = ravenCards[index]
            InfoCard(card.label, tint = PanelDark3)
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("Relevant", {
                    lastNote = noteFor(card)
                }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("Irrelevant", {
                    lastNote = noteFor(card)
                }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
            if (lastNote != null) {
                Spacer(Modifier.height(12.dp))
                InfoCard(lastNote ?: "", tint = Color(0xFF171025))
                Spacer(Modifier.height(12.dp))
                ArcadeButton("Next", {
                    index += 1
                    lastNote = null
                }, modifier = Modifier.fillMaxWidth())
            }
        } else {
            InfoCard(
                "\"All ravens are black\" logically means exactly the same thing as \"everything that isn't " +
                    "black isn't a raven.\" So finding a red apple - not black, not a raven - technically " +
                    "counts as a tiny piece of confirming evidence for the raven claim, even though it feels " +
                    "totally unrelated. That's the Raven Paradox: the logic checks out, and it still feels wrong.",
                tint = PanelDark3
            )
            Spacer(Modifier.height(12.dp))
            ArcadeButton("Continue", { onComplete("Sorted ${ravenCards.size} objects; even the apple counted.") }, modifier = Modifier.fillMaxWidth(), tint = GoodGreen)
        }
    }
}

private fun noteFor(card: RavenCard): String {
    return if (card.isRaven && card.isBlack) {
        "A black raven directly supports the claim - textbook confirming evidence."
    } else {
        "Not a raven, and not black. By strict logic (the two statements are equivalent), this technically " +
            "counts as confirming evidence too - just an almost immeasurably tiny amount."
    }
}
