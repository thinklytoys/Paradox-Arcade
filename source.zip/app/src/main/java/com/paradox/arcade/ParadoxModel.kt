package com.paradox.arcade

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.random.Random

/**
 * Shared state across every level. The ledger records what the player concluded
 * in each level - both for the hub's completion checkmarks, and because a few
 * later levels quietly read what earlier levels decided.
 */
class GameState {
    val ledger = mutableStateMapOf<String, String>()

    // The Bootstrap Paradox loop: this code exists from the moment the app
    // launches, before the player has "created" it anywhere. It is only
    // revealed into `vaultCode` once Level 9 is completed - at which point
    // it can be carried back to Level 3, which has been waiting for it,
    // unsolved, this whole time.
    private val hiddenCode: String = (1..4).joinToString("") { Random.nextInt(0, 10).toString() }
    var vaultCode: String? by mutableStateOf(null)
    var chestOpened: Boolean by mutableStateOf(false)

    fun revealVaultCode() {
        vaultCode = hiddenCode
    }

    fun isDone(id: String): Boolean = ledger.containsKey(id)
}

data class LevelMeta(
    val id: String,
    val title: String,
    val paradoxName: String,
    val teaser: String
)

val levelOrder: List<LevelMeta> = listOf(
    LevelMeta("l1", "The Endless Chase", "Achilles and the Tortoise",
        "Close the gap. Again. And again. And again."),
    LevelMeta("l2", "The Old Ship", "Ship of Theseus",
        "Replace every plank, one at a time. Is it still the same ship?"),
    LevelMeta("l3", "The Locked Chest", "Bootstrap Paradox",
        "A four-digit code. It doesn't exist yet. Or does it?"),
    LevelMeta("l4", "The Heap", "Sorites Paradox",
        "Remove one grain at a time. Find the exact moment it stops being a heap."),
    LevelMeta("l5", "The Truth Machine", "Liar Paradox",
        "Sort every statement into true or false. One of them will not sort."),
    LevelMeta("l6", "Three Doors", "Monty Hall Problem",
        "Pick a door. Then decide whether to trust your first instinct."),
    LevelMeta("l7", "No Vacancy", "Hilbert's Grand Hotel",
        "The hotel is completely full. Guests keep arriving anyway."),
    LevelMeta("l8", "Two Boxes", "Newcomb's Paradox",
        "A predictor has already decided what's in the box - based on what you'll choose."),
    LevelMeta("l9", "The Signal", "Bootstrap Paradox",
        "Decode a number that seems to come from absolutely nowhere."),
    LevelMeta("l10", "Two Children", "Boy or Girl Paradox",
        "One small fact changes the odds far more than feels reasonable."),
    LevelMeta("l11", "All Ravens", "Raven Paradox",
        "A green apple, logically, is a tiny piece of evidence about ravens.")
)

const val FINALE_ID = "finale"
