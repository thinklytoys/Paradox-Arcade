package com.paradox.arcade

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val NeonPink = Color(0xFFFF3D9A)
val NeonCyan = Color(0xFF39F2E0)
val GoodGreen = Color(0xFF63FFB0)
val WarnRed = Color(0xFFFF5252)
val InkText = Color(0xFFF3EFFA)
val PanelColor = Color(0xFF241A38)

sealed interface Screen {
    data class Intro(val page: Int) : Screen
    data object Hub : Screen
    data class Level(val id: String) : Screen
    data object Finale : Screen
}

@Composable
fun ParadoxApp() {
    val colors = darkColorScheme(
        primary = NeonPink,
        onPrimary = Color(0xFF1A0512),
        background = Color(0xFF0B0714),
        onBackground = InkText,
        surface = Color(0xFF171025),
        onSurface = InkText,
        surfaceVariant = PanelColor,
        onSurfaceVariant = Color(0xFFC7BEDD),
        error = WarnRed
    )
    MaterialTheme(colorScheme = colors) {
        var screen by remember { mutableStateOf<Screen>(Screen.Intro(0)) }
        val state = remember { GameState() }

        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            when (val s = screen) {
                is Screen.Intro -> IntroView(
                    page = s.page,
                    onNext = { screen = if (s.page + 1 < introPages.size) Screen.Intro(s.page + 1) else Screen.Hub },
                    onSkip = { screen = Screen.Hub }
                )

                is Screen.Hub -> HubView(
                    state = state,
                    onOpenLevel = { id -> screen = Screen.Level(id) },
                    onOpenFinale = { screen = Screen.Finale }
                )

                is Screen.Level -> LevelDispatcher(
                    id = s.id,
                    state = state,
                    onComplete = { summary ->
                        state.ledger[s.id] = summary
                        screen = Screen.Hub
                    },
                    onExit = { screen = Screen.Hub }
                )

                is Screen.Finale -> FinaleView(state = state, onExit = { screen = Screen.Hub })
            }
        }
    }
}

@Composable
fun LevelDispatcher(id: String, state: GameState, onComplete: (String) -> Unit, onExit: () -> Unit) {
    when (id) {
        "l1" -> Level1Achilles(onComplete)
        "l2" -> Level2Ship(onComplete)
        "l3" -> Level3Chest(state, onComplete)
        "l4" -> Level4Heap(onComplete)
        "l5" -> Level5Liar(onComplete)
        "l6" -> Level6MontyHall(onComplete)
        "l7" -> Level7Hotel(onComplete)
        "l8" -> Level8Newcomb(onComplete)
        "l9" -> Level9Signal(state, onComplete)
        "l10" -> Level10BoyGirl(onComplete)
        "l11" -> Level11Ravens(onComplete)
        else -> {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
                Text("Unknown level.", color = InkText)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onExit) { Text("Back", maxLines = 1, softWrap = false) }
            }
        }
    }
}

// --------------------------------------------------------- Shared widgets

@Composable
fun LevelScaffold(
    title: String,
    paradoxName: String,
    onExit: () -> Unit,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            paradoxName.uppercase(),
            color = NeonCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false
        )
        Spacer(Modifier.height(4.dp))
        Text(title, color = NeonPink, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        content()
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onExit) {
            Text("‹ Back to hub", maxLines = 1, softWrap = false)
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun ArcadeButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = NeonPink) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(containerColor = tint, contentColor = Color(0xFF1A0512)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun InfoCard(text: String, tint: Color = PanelColor, textColor: Color = InkText) {
    Surface(color = tint, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Text(text, color = textColor, fontSize = 15.sp, modifier = Modifier.padding(14.dp))
    }
}

// ------------------------------------------------------------------ Intro

private data class IntroPage(val heading: String, val body: String, val signoff: String? = null, val cta: String = "Continue")

private val introPages = listOf(
    IntroPage(
        heading = "A note before you start.",
        body = "This game was built by a curious engineer - someone who writes code for a living, " +
            "but who keeps getting distracted by strange little puzzles that don't quite resolve. " +
            "The kind of thing you turn over at 2 a.m. and can't quite put down."
    ),
    IntroPage(
        heading = "Paradoxes, made playable.",
        body = "Every level here is one real paradox - some from ancient philosophy, some from modern " +
            "probability and physics, one or two that professional thinkers still argue about. " +
            "You won't just read about them. You'll play them, and some of them will play you back.",
        signoff = "Have fun. Question everything. Especially the ending.",
        cta = "Enter the arcade"
    )
)

@Composable
private fun IntroView(page: Int, onNext: () -> Unit, onSkip: () -> Unit) {
    val p = introPages.getOrElse(page) { introPages.last() }
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(24.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("PARADOX ARCADE", color = NeonPink, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, softWrap = false)
        Spacer(Modifier.height(40.dp))
        Text(p.heading, color = InkText, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))
        Text(p.body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 17.sp)
        if (p.signoff != null) {
            Spacer(Modifier.height(20.dp))
            Text(p.signoff, color = NeonCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(32.dp))
        Row {
            for (i in introPages.indices) {
                Box(
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .height(8.dp)
                        .width(if (i == page) 22.dp else 8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (i == page) NeonPink else PanelColor)
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        ArcadeButton(p.cta + "  →", onNext, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        if (page < introPages.size - 1) {
            OutlinedButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                Text("Skip intro", maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ------------------------------------------------------------------- Hub

@Composable
private fun HubView(state: GameState, onOpenLevel: (String) -> Unit, onOpenFinale: () -> Unit) {
    val scroll = rememberScrollState()
    val doneCount = levelOrder.count { state.isDone(it.id) }
    val allDone = doneCount >= levelOrder.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text("PARADOX ARCADE", color = NeonPink, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text("$doneCount / ${levelOrder.size} paradoxes solved", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))

        for ((index, meta) in levelOrder.withIndex()) {
            val unlocked = index == 0 || state.isDone(levelOrder[index - 1].id) || state.isDone(meta.id)
            LevelCard(meta = meta, unlocked = unlocked, done = state.isDone(meta.id), onClick = { if (unlocked) onOpenLevel(meta.id) })
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(10.dp))
        FinaleCard(unlocked = allDone, onClick = { if (allDone) onOpenFinale() })
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun LevelCard(meta: LevelMeta, unlocked: Boolean, done: Boolean, onClick: () -> Unit) {
    val bg = if (unlocked) PanelColor else Color(0xFF171025)
    val titleColor = if (unlocked) InkText else Color(0xFF5A5270)
    Surface(
        color = bg,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(meta.paradoxName.uppercase(), color = if (unlocked) NeonCyan else Color(0xFF5A5270), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                Text(
                    when {
                        done -> "✓ solved"
                        unlocked -> "tap to play"
                        else -> "locked"
                    },
                    color = if (done) GoodGreen else Color(0xFF5A5270),
                    fontSize = 11.sp,
                    maxLines = 1,
                    softWrap = false
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(meta.title, color = titleColor, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            if (unlocked) {
                Spacer(Modifier.height(4.dp))
                Text(meta.teaser, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FinaleCard(unlocked: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (unlocked) Color(0xFF3A0F26) else Color(0xFF171025),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().clickable(enabled = unlocked) { onClick() }
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("??? FINAL QUESTION", color = if (unlocked) NeonPink else Color(0xFF5A5270), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                if (unlocked) "One last question. Answer it, and the door opens." else "Solve every paradox above to unlock this.",
                color = if (unlocked) InkText else Color(0xFF5A5270),
                fontSize = 14.sp
            )
        }
    }
}

// ---------------------------------------------------------------- Finale

@Composable
private fun FinaleView(state: GameState, onExit: () -> Unit) {
    val context = LocalContext.current
    var answered by remember { mutableStateOf<Boolean?>(null) }
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scroll)
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text("THE LAST QUESTION", color = NeonPink, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        Text("The Crocodile Paradox", color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))

        InfoCard(
            "A door stands in front of you. A voice makes you a promise: " +
                "\"Answer correctly, and this door opens. Answer wrong, and it stays shut forever.\" " +
                "Then it asks you one question:"
        )
        Spacer(Modifier.height(14.dp))
        Text("\"Will this door open?\"", color = InkText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))

        if (answered == null) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ArcadeButton("Yes", { answered = true }, modifier = Modifier.weight(1f), tint = NeonCyan)
                ArcadeButton("No", { answered = false }, modifier = Modifier.weight(1f), tint = NeonPink)
            }
        } else {
            val saidYes = answered == true
            InfoCard(
                if (saidYes)
                    "You said: the door will open. For that to be correct, the door must open. " +
                        "But whether your answer was correct is only decided by what the door then does - " +
                        "which was supposed to depend on whether you were correct. There is no order " +
                        "to run this in that doesn't loop back on itself."
                else
                    "You said: the door will not open. For that to be correct, the door must stay shut. " +
                        "But if it stays shut because you were right, then you correctly answered the question - " +
                        "which, by the door's own rule, should have opened it. There is no order " +
                        "to run this in that doesn't loop back on itself.",
                tint = Color(0xFF3A0F26)
            )
            Spacer(Modifier.height(14.dp))
            InfoCard(
                "This is the Crocodile Paradox: a promise that refers to its own outcome has no answer that " +
                    "satisfies it. Not a hard puzzle. Not a trick. An actual hole in the rules, the same shape " +
                    "as the Liar Paradox, the same shape Gödel found hiding inside mathematics itself.",
                tint = PanelColor
            )
            Spacer(Modifier.height(14.dp))
            Text("So the door doesn't open. That was never a bug - it's the last thing this game has to say.", color = NeonCyan, fontSize = 15.sp, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(22.dp))
            Text("YOUR PROOF LEDGER", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            for (meta in levelOrder) {
                val entry = state.ledger[meta.id] ?: "—"
                InfoCard("${meta.title}: $entry", tint = Color(0xFF171025), textColor = Color(0xFFC7BEDD))
                Spacer(Modifier.height(6.dp))
            }

            Spacer(Modifier.height(18.dp))
            ArcadeButton("Share this ending", {
                shareText(
                    context,
                    "I just 'finished' Paradox Arcade. Spoiler: you can't. The last question is the " +
                        "Crocodile Paradox and it has no valid answer, on purpose. Try it yourself."
                )
            }, modifier = Modifier.fillMaxWidth())
        }

        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onExit) { Text("‹ Back to hub", maxLines = 1, softWrap = false) }
        Spacer(Modifier.height(24.dp))
    }
}

fun shareText(context: Context, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, "Share"))
    } catch (t: Throwable) {
        // No share target available - fail quietly.
    }
}
